#include <GL/glut.h>

int previousMouseHorizontalPosition = 0;
int previousMouseVerticalPosition = 0;
float rotationAngleHorizontal = 0.0f;
float rotationAngleVertical = 0.0f;

void display() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	glClearDepth(1.0);
	glEnable(GL_DEPTH_TEST);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
    gluPerspective(60, 1.3f, 0.1f, 100.0f);

    glMatrixMode(GL_MODELVIEW);

    glLoadIdentity();
    glTranslatef(0.0f, 0.0f, -5.0f);
    glRotatef(rotationAngleHorizontal, 0.0f, 1.0f, 0.0f);
    glRotatef(rotationAngleVertical, 1.0f, 0.0f, 0.0f);
	
	glPushMatrix();
    glColor3f(1.0f, 0.85f, 0.69f);
    glTranslatef(0.0f, 1.0f, 0.0f);
    glutSolidSphere(0.5f, 30.0f, 30.0f);
	glPopMatrix();
	
	glPushMatrix();
    glColor3f(1.0f, 0.85f, 0.69f);
    glScalef(-0.35f, -0.35f, -0.35f);
    glTranslatef(0.0f, -1.8f, 0.0f);
    glRotatef(90, 1.0f, 0.0f, 0.0f);
    glutSolidTorus(0.5f, 1.5f, 20.0f, 20.0f);
	glPopMatrix();

	glPushMatrix();
    glColor3f(1.0f, 0.85, 0.69);
    glScalef(-1.5f, -1.5f, -1.5f);
    glTranslatef(0.0f, 0.8f, 0.0f);
    glRotatef(90, 1.0f, 0.0f, 0.0f);
    glutSolidCone(0.3f, 1.5f, 20.0f, 20.0f);
	glPopMatrix();
	
	glPushMatrix();
    glColor3f(1.0f, 0.85f, 0.69f);
    glScalef(-1.5f, -1.5f, -1.5f);
    glTranslatef(0.0f, -0.4f, 0.0f);
    glRotatef(270, 1.0f, 0.0f, 0.0f);
    glutSolidCone(0.3f, 0.5f, 20.0f, 20.0f);
	glPopMatrix();

	glPushMatrix();
    glColor3f(1.0f, 0.85f, 0.69f);
    glScalef(-0.35f, -0.35f, -0.35f);
    glRotatef(90, 1.0f, 0.0f, 0.0f);
    glTranslatef(0.0f, 0.0f, -3.8f);
    glutSolidTorus(0.5f, 1.5f, 20.0f, 20.0f);
	glPopMatrix();
	
	glPushMatrix();
    glColor3f(1.0f, 0.85f, 0.69f);
    glScalef(-0.25f, -0.25f, -0.25f);
    glRotatef(90, 1.0f, 0.0f, 0.0f);
    glTranslatef(0.0f, 0.0f, -4.2f);
    glutSolidTorus(0.5f, 1.5f, 20.0f, 20.0f);
	glPopMatrix();
	
    glFlush();
}

void mouseMotion(int x, int y)
{
    int deltaHorizontal = x - previousMouseHorizontalPosition;
    int deltaVertical = y - previousMouseVerticalPosition;
    
    rotationAngleHorizontal += deltaHorizontal * 0.5f;
    rotationAngleVertical += deltaVertical * 0.5f; 
    
    previousMouseHorizontalPosition = x;
    previousMouseVerticalPosition = y;

    glutPostRedisplay();
}

void mouseClick(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        previousMouseHorizontalPosition = x;
        previousMouseVerticalPosition = y;
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
    glutDisplayFunc(display);
    glutMotionFunc(mouseMotion);
    glutMouseFunc(mouseClick);
    glutMainLoop();
    return 0;
}

