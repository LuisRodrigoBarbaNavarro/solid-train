#include <GL/glut.h>
void draw(void)
{
	glClearColor(0.00, 0.21, 0.21, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1, 0.97, 0.32);
	glLineWidth(4);
	glBegin(GL_LINE_LOOP);
		glVertex2f(-0.8035, -0.1216);
		glVertex2f(-0.2310, 0.4448);
		glVertex2f(0.8074, 0.109);
		glVertex2f(0.0491, -0.1094);
		glVertex2f(0.2, -0.6);
	glEnd();
	glFlush();
}
int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
	glutDisplayFunc(draw);
	glutMainLoop();
	return 0;
}