#include <GL/glut.h>
void draw(void)
{
	glClearColor(0.0, 0.0, 0.31, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	glShadeModel(GLU_SMOOTH);
	glBegin(GL_QUAD_STRIP);
	
	glColor3f(0,0,1);
	glVertex2f(-0.6, -0.2);
	glVertex2f(-0.6, 0.2);
	
	glColor3f(1, 0, 1);
	glVertex2f(-0.2, -0.2);
	glVertex2f(-0.2, 0.2);

	glColor3f(0, 1, 1);
	glVertex2f(0.2, -0.2);
	glVertex2f(0.2, 0.2);
	
	glColor3f(1, 0, 0);
	glVertex2f(0.6, -0.2);
	glVertex2f(0.6, 0.2);
	
	glEnd();
	glFlush();
}
int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
	glutDisplayFunc(draw);
	glutMainLoop();
	return 0;
}
