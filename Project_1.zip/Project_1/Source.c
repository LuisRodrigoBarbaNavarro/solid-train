﻿#include<GL/glut.h>
void Inicializa(void)
{
    glClearColor(0.74, 0.60, 0.89, 1.0);

    glClear(GL_COLOR_BUFFER_BIT);


    glFlush(); 
}
main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowSize(640, 480);
    glutInitWindowPosition(200, 200);

    glutCreateWindow("BARBA NAVARRO LUIS RODRIGO - 20490687");
    glutDisplayFunc(Inicializa);

    glutMainLoop();

    return 0;
}