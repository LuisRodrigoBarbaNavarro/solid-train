#include <GL/glut.h>
#include <GL/gl.h>
void inicializar(void)
{
	glClearColor(0,0,0,0);
}
void dibujar(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	
	glPushMatrix();
	glTranslatef(0,.5,0);
	glColor3f(.5,.5,.5);
	glutSolidSphere(.1,25,25);
	glPopMatrix();
	
	glPushMatrix();
	glTranslatef(.5,0,0);
	glColor3f(.8,.5,.5);
	glutSolidSphere(.1,25,25);
	glPopMatrix();
	
	glFlush();
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(500,500);
	glutInitWindowPosition(100,100);
	glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
	inicializar();
	
	glutDisplayFunc(dibujar);
	glutMainLoop();
	return 0;
}
