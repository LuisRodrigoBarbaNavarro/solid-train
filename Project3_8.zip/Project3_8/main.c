#include <GL/glut.h>

void display() {
  
  glClearColor(0.0, 0.0, 0.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);

  glMatrixMode(GL_PROJECTION);
  gluPerspective(100.0, 1.0, 1.0, 1.0);

  glMatrixMode(GL_MODELVIEW);
  
  // Cono (Cobertura)
  glLoadIdentity();
  glColor3f(0.93, 0.57, 0.32);
  glRotatef(90, 1.0, 0.0, 0.0);
  glRotatef(25, 0.0, 1.0, 1.0);
  glScalef(1.0f, 1.0f, 0.85f); 
  glutSolidCone(0.35, 1.25, 20, 20);
  
  // Cono (Galleta)
  glLoadIdentity();
  glColor3f(0.51, 0.28, 0.12);
  glRotatef(90, 1.0, 0.0, 0.0);
  glRotatef(25, 0.0, 1.0, 1.0);
  glLineWidth(4);
  glScalef(1.0f, 1.0f, 0.85f);
  glutWireCone(0.35, 1.25, 35, 20);
 
  // Bola (Chocolate)
  glLoadIdentity();
  glColor3f(0.2, 0.1, 0.02);
  glRotatef(90, 1.0, 0.0, 0.0);
  glRotatef(25, 0.0, 1.0, 1.0);
  glTranslatef(-0.005, 0.0, -0.075);
  glScalef(1.0f, 1.0f, 0.85f);
  glutSolidSphere(0.33, 32, 32);

  // Bola (Fresa)
  glLoadIdentity();
  glColor3f(0.78, 0.28, 0.28);
  glRotatef(90, 1.0, 0.0, 0.0);
  glRotatef(25, 0.0, 1.0, 1.0);
  glTranslatef(-0.0075, 0.0, -0.40);
  glScalef(1.0f, 1.0f, 0.85f);
  glutSolidSphere(0.33, 32, 32);
  
  // Bola (Vainilla)
  glLoadIdentity();
  glColor3f(1, 0.83, 0.5);
  glRotatef(90, 1.0, 0.0, 0.0);
  glRotatef(25, 0.0, 1.0, 1.0);
  glTranslatef(-0.005, 0.0, -0.65);
  glScalef(1.0f, 1.0f, 0.85f);
  glutSolidSphere(0.31, 32, 32);
  
  // Cereza
  glLoadIdentity();
  glColor3f(0.97, 0.12, 0.12);
  glRotatef(90, 1.0, 0.0, 0.0);
  glRotatef(25, 0.0, 1.0, 1.0);
  glTranslatef(-0.001, 0.0, -0.95);
  glScalef(1.0f, 1.0f, 0.85f);
  glutSolidSphere(0.11, 32, 32);
  
  glFlush();
}

int main(int argc, char** argv) {
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(500, 500);
  glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
  glutDisplayFunc(display);
  glutMainLoop();
  return 0;
}
