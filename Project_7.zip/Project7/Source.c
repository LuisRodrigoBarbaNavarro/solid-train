#include <GL/glut.h>
void draw(void)
{
	glClearColor(0.57, 0.54, 1.00, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);
	
	glPointSize(20);
	glLineWidth(10);

	glColor3f(0.88, 1, 0.23);

	// Line-1
	glBegin(GL_LINES);
		glVertex2f(-0.725,-0.334);
		glVertex2f(0.071, 0.547);
	glEnd();

	// Line-2
	glBegin(GL_LINES);
		glVertex2f(-0.725,-0.334);
		glVertex2f(0.659, -0.334);
	glEnd();

	// Line-3
	glBegin(GL_LINES);
		glVertex2f(0.071, 0.547);
		glVertex2f(0.659, -0.334);
	glEnd();

	glColor3f(0.23, 1, 0.47);

	// Line-4
	glBegin(GL_LINES);
		glVertex2f(-0.433,0.362);
		glVertex2f(0.489,0.362);
	glEnd();

	// Line-5
	glBegin(GL_LINES);
		glVertex2f(-0.433,0.362);
		glVertex2f(-0.006, -0.442);
	glEnd();
	
	// Line-6
	glBegin(GL_LINES);
		glVertex2f(0.489, 0.386);
		glVertex2f(-0.006, -0.442);
	glEnd();

	glColor3f(1, 0.23, 0.23);

	// Point-1
	glBegin(GL_POINTS);
		glVertex2f(-0.725,-0.334);
	glEnd();

	// Point-2
	glBegin(GL_POINTS);
		glVertex2f(-0.006,-0.442);
	glEnd();

	// Point-3
	glBegin(GL_POINTS);
		glVertex2f(0.659,-0.334);
	glEnd();

	// Point-4
	glBegin(GL_POINTS);
		glVertex2f(0.489,0.362);
	glEnd();

	// Point-5
	glBegin(GL_POINTS);
		glVertex2f(0.071,0.547);
	glEnd();

	// Point-6
	glBegin(GL_POINTS);
		glVertex2f(-0.433,0.362);
	glEnd();

	glFlush();
}
int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
	glutDisplayFunc(draw);
	glutMainLoop();
	return 0;
}