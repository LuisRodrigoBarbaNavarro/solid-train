#include <GL/glut.h>
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	
	glColor3f(1, 0.36, 0.36);
	glBegin(GL_POLYGON);
		glVertex2f(0, -2);
		glVertex2f(-2, 0);
		glVertex2f(0, 2);
		glVertex2f(2, 0);
	glEnd();
	
	glTranslatef (-2,-4,0);
	
	glColor3f(0.35, 0.46, 1);
	glBegin(GL_POLYGON);
		glVertex2f(0, -2);
		glVertex2f(-2, 0);
		glVertex2f(0, 2);
		glVertex2f(2, 0);
	glEnd();
	
	glFlush();
}
void init(void)
{
	glClearColor(0.79, 1.00, 0.53, 1.0);
	glOrtho(-15, 10, -15, 10, -5, 5);
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(200, 200);
	glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
