#include <GL/glut.h>
#include <math.h>

float x = 0.0f;
float y = 0.0f;
float radius = 1.5f;

void display() {
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
  
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);
  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(100.0f, 1.0f, 1.0f, 1.0f);

  glMatrixMode(GL_MODELVIEW);
  
  // Torus (S�lido)
  glLoadIdentity();
  
  glColor3f(1, 0, 0.25);
  glScalef(0.25f, 0.25f, 0.25f);
  glRotatef(45, 1.0, 1.0, 1.0);

  glutSolidTorus(0.75, 1.25, 50, 50);

  // Torus (Alambre)
  glLoadIdentity();
  
  glColor3f(1, 0.38, 0.53);
  glLineWidth(2);
  glScalef(0.25f, 0.25f, 0.25f);
  glRotatef(45, 1.0, 1.0, 1.0);
  
  glutWireTorus(0.75, 1.25, 30, 30);

  // Esfera (S�lida)
  glLoadIdentity();
  
  glColor3f(0, 0.54, 1);
  glScalef(0.25f, 0.25f, 0.25f);
  glRotatef(45, 1.0, 1.0, 1.0);
  
  glTranslatef(1.5, 0.0, 0.0);
  glRotatef(90, 1.0, 0.0, 0.0);

  static float angle = 0.0f;
  angle += 0.0007f;
  x = radius * cos(angle);
  y = radius * sin(angle);
  
  glTranslatef(x, y, 0.0);
  
  glutSolidSphere(0.40, 50, 50);
  
  glColor3f(0.67, 0.76, 1);
  glutWireSphere(0.40, 20, 20);
  
  glFlush();
}

int main(int argc, char** argv) {
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE | GLUT_DEPTH);
  glutInitWindowSize(640, 640);
  glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
  glutDisplayFunc(display);
  glutIdleFunc(display);
  glutMainLoop();
  return 0;
}
