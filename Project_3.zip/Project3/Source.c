#include <GL/glut.h>

void draw(void)
{
    glClearColor(0.57, 0.54, 1.00, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glPointSize(5);
    glColor3f(0.0, 0.0, 0.0);

    glBegin(GL_POINTS);
    // Generar la cadena "Luis" con puntos.
    // Letra 'L'
    glVertex2f(-0.83, 0.34);
    glVertex2f(-0.83, 0.27);
    glVertex2f(-0.83, 0.20);
    glVertex2f(-0.83, 0.13);
    
    glVertex2f(-0.79, 0.06);
    glVertex2f(-0.72, 0.06);
    glVertex2f(-0.65, 0.06);

    // Letra 'U'
    glVertex2f(-0.53, 0.34);
    glVertex2f(-0.53, 0.27);
    glVertex2f(-0.53, 0.20);
    glVertex2f(-0.53, 0.13);

    glVertex2f(-0.49, 0.06);
    glVertex2f(-0.42, 0.06);
    glVertex2f(-0.35, 0.06);

    glVertex2f(-0.31, 0.34);
    glVertex2f(-0.31, 0.27);
    glVertex2f(-0.31, 0.20);
    glVertex2f(-0.31, 0.13);

    // Letra 'I'
    glVertex2f(-0.14, 0.34);
    glVertex2f(-0.14, 0.27);
    glVertex2f(-0.14, 0.20);
    glVertex2f(-0.14, 0.13);
    glVertex2f(-0.14, 0.06);

    // Letra 'S'
    glVertex2f(0.07, 0.34);
    glVertex2f(0.14, 0.34);
    glVertex2f(0.21, 0.34);

    glVertex2f(0, 0.27);
    glVertex2f(0, 0.20);

    glVertex2f(0.07, 0.20);
    glVertex2f(0.14, 0.20);

    glVertex2f(0.21, 0.20);
    glVertex2f(0.21, 0.13);

    glVertex2f(0, 0.06);
    glVertex2f(0.07, 0.06);
    glVertex2f(0.14, 0.06);

    glEnd();
    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowSize(400, 400);
    glutInitWindowPosition(100, 100);

    glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");

    glutDisplayFunc(draw);

    glutMainLoop();
    return 0;
}