#include <GL/glut.h>
#include <GL/gl.h>
void inicializar(void)
{
	glClearColor(0,0,0,0);
}
void dibujar(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glTranslatef(0,.5,0);
	glColor3f(.5,.5,.5);
	glutSolidSphere(.1,25,25);
	
	glTranslatef(.5,0,0);
	glColor3f(.8,.5,.5);
	glutSolidSphere(.1,25,25);
	glFlush();
	
	/*
	La raz�n por la que la segunda esfera aparece tambi�n en la coordenada (0.5, 0.5) como la primera
	esfera es debido a que la segunda esfera se crea sin haber restaurado la posici�n original, que se 
	modific� al momento de crear la primera esfera. Por lo tanto, la traslaci�n de la segunda esfera se
	basa en la posici�n modificada por la primera esfera. Se podr�a solucionar restaurando a la posici�n
	origen antes de crear la segunda esfera.
	- Barba Navarro Luis Rodrigo
	*/
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(500,500);
	glutInitWindowPosition(100,100);
	glutCreateWindow("Barba Navarro Luis Rodrigo - 20490687");
	inicializar();
	
	glutDisplayFunc(dibujar);
	glutMainLoop();
	return 0;
}
